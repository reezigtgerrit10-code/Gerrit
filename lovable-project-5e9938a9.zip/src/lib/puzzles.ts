// All puzzles for the Dieren Escape Room — built from every slide of the spreekbeurt.
// Each correct answer reveals a DIGIT. The vault opens with the LAST 7 digits
// (so the kids verzamelen wel 30 cijfers, maar typen er maar 7 in de eindkluis).

export type Puzzle = {
  id: string;
  title: string;
  image: string;
  briefing: string[];
  fact: string;
  question: string;
  hint: string;
  type: "number" | "text" | "choice" | "order";
  answer: string | string[];
  choices?: string[];
  items?: string[];
  digit: string; // unlocked code piece
};

export type Room = {
  id: string;
  name: string;
  subtitle: string;
  emoji: string;
  accent: string;
  puzzles: Puzzle[];
};

const img = (n: number) => (n === 28 ? `/escape2/image28.png` : `/escape2/image${n}.jpeg`);

export const ROOMS: Room[] = [
  {
    id: "deer",
    name: "Het Hertenbos",
    subtitle: "Kamer 1 • Diep in het donkere bos",
    emoji: "🦌",
    accent: "from-amber-700/40 to-emerald-900/40",
    puzzles: [
      {
        id: "d1",
        title: "Hoeveel soorten herten?",
        image: img(2),
        digit: "9",
        briefing: [
          "Welkom in het Hertenbos. Op een houten plank ligt een dik onderzoeksboek.",
          "Pagina twee: 'Wereldwijd zijn er ongeveer NEGENTIG soorten herten.' Onthoud dat aantal.",
        ],
        fact: "Wereldwijd leven er ongeveer 90 verschillende hertensoorten.",
        question: "Hoeveel hertensoorten leven er op de hele wereld?",
        hint: "Een rond getal vlak onder de honderd.",
        type: "choice",
        choices: ["50", "70", "90", "120"],
        answer: "90",
      },
      {
        id: "d2",
        title: "Mannetje of vrouwtje?",
        image: img(4),
        digit: "1",
        briefing: [
          "Een oude tekening hangt tussen de bomen: twee herten naast elkaar.",
          "Het ene heeft een groot vertakt gewei, het andere niets. Alleen mannetjes krijgen elk jaar een gewei.",
        ],
        fact: "Alleen mannetjeshertjes hebben een gewei. Vrouwtjes nooit.",
        question: "Wat heeft alleen een mannetjeshert?",
        hint: "Het zit op zijn hoofd en heeft takken.",
        type: "text",
        answer: ["gewei", "een gewei", "het gewei"],
      },
      {
        id: "d3",
        title: "Het kleinste hert van Nederland",
        image: img(6),
        digit: "2",
        briefing: [
          "Een boswachter heeft een tabel achtergelaten.",
          "De REE is met 25–35 kg het kleinste hert van Nederland. Het edelhert is juist het grootste.",
        ],
        fact: "De ree is het kleinste hert van Nederland.",
        question: "Welk hert is het KLEINSTE in Nederland?",
        hint: "Het rijmt op 'thee'.",
        type: "choice",
        choices: ["Edelhert", "Damhert", "Ree", "Rendier"],
        answer: "Ree",
      },
      {
        id: "d4",
        title: "De reus van het bos",
        image: img(7),
        digit: "3",
        briefing: [
          "Een spoor van enorme hoefafdrukken loopt door de modder.",
          "Op een bordje: 'Het EDELHERT is met ruim 200 kg het grootste hert van Nederland.'",
        ],
        fact: "Het edelhert is het grootste hert van Nederland.",
        question: "Welk hert is het GROOTSTE in Nederland?",
        hint: "Begint met 'edel'.",
        type: "choice",
        choices: ["Ree", "Damhert", "Edelhert", "Rendier"],
        answer: "Edelhert",
      },
      {
        id: "d5",
        title: "Wanneer valt het gewei af?",
        image: img(5),
        digit: "4",
        briefing: [
          "Onder een eik ligt een afgeworpen gewei in de sneeuw.",
          "Elk jaar in de WINTER valt het gewei van een hert af. In de lente groeit een nieuw, vaak groter gewei.",
        ],
        fact: "Het gewei valt elke winter af en groeit in het voorjaar weer aan.",
        question: "In welk seizoen valt het gewei van een hert af?",
        hint: "Het seizoen met sneeuw en kou.",
        type: "choice",
        choices: ["Lente", "Zomer", "Herfst", "Winter"],
        answer: "Winter",
      },
      {
        id: "d6",
        title: "Wat eet een hert?",
        image: img(8),
        digit: "5",
        briefing: [
          "In een houten kistje liggen voorbeelden: blaadjes, knoppen, gras, mos en eikels.",
          "Een hert is een PLANTENETER (herbivoor). Vlees staat niet op het menu.",
        ],
        fact: "Herten zijn planteneters: ze eten gras, blaadjes, knoppen en vruchten.",
        question: "Wat voor soort eter is een hert?",
        hint: "Het rijmt op 'tenenleter' — eet alleen planten.",
        type: "choice",
        choices: ["Vleeseter", "Alleseter", "Planteneter", "Insecteneter"],
        answer: "Planteneter",
      },
      {
        id: "d7",
        title: "Het burlen",
        image: img(9),
        digit: "6",
        briefing: [
          "Vanuit de verte hoor je een diepe brullende roep door het bos galmen.",
          "Dat is BURLEN: mannetjes roepen vrouwtjes in de HERFST tijdens de bronsttijd.",
        ],
        fact: "Herten burlen in de herfst tijdens de bronst.",
        question: "In welk seizoen burlen de mannetjes?",
        hint: "De tijd van vallende bladeren.",
        type: "choice",
        choices: ["Lente", "Zomer", "Herfst", "Winter"],
        answer: "Herfst",
      },
      {
        id: "d8",
        title: "Hoe oud wordt een hert?",
        image: img(10),
        digit: "7",
        briefing: [
          "Op een vergeelde poster: 'In het wild wordt een hert gemiddeld ongeveer 15 jaar oud.'",
          "In een dierentuin kan hij iets ouder worden, maar in de natuur is 15 al heel oud.",
        ],
        fact: "In het wild wordt een hert ongeveer 15 jaar oud.",
        question: "Hoe oud wordt een hert gemiddeld in het wild?",
        hint: "Halverwege tien en twintig.",
        type: "number",
        answer: "15",
      },
      {
        id: "d9",
        title: "Hoeveel jongen per worp?",
        image: img(11),
        digit: "8",
        briefing: [
          "In het mos ligt een tekening van een hertenmoeder met haar kalfje.",
          "Een hinde krijgt meestal maar 1 kalfje per jaar. Heel soms zijn het er twee.",
        ],
        fact: "Een hinde krijgt meestal 1 kalfje per jaar.",
        question: "Hoeveel kalfjes krijgt een hertenmoeder meestal per jaar?",
        hint: "Het laagste hele getal boven nul.",
        type: "number",
        answer: "1",
      },
      {
        id: "d10",
        title: "Herkauwer of niet?",
        image: img(12),
        digit: "9",
        briefing: [
          "Een hert ligt rustig onder een boom en kauwt en kauwt en kauwt.",
          "Herten zijn HERKAUWERS — net als koeien. Ze kauwen hun eten een tweede keer, om het beter te verteren.",
        ],
        fact: "Herten zijn herkauwers, net als koeien.",
        question: "Is een hert een herkauwer?",
        hint: "Hij doet hetzelfde als een koe in de wei.",
        type: "choice",
        choices: ["Ja", "Nee"],
        answer: "Ja",
      },
    ],
  },
  {
    id: "calf",
    name: "De Kalverstal",
    subtitle: "Kamer 2 • Op de boerderij",
    emoji: "🐄",
    accent: "from-yellow-700/30 to-orange-900/40",
    puzzles: [
      {
        id: "c1",
        title: "Brown Swiss",
        image: img(17),
        digit: "4",
        briefing: [
          "In de stal hangt een foto van een lichtbruine, krachtige koe.",
          "Bordje: 'BROWN SWISS — een van de oudste melkrassen ter wereld, uit Zwitserland.'",
        ],
        fact: "De Brown Swiss is een Zwitsers melkras.",
        question: "Uit welk land komt het Brown Swiss-koeienras?",
        hint: "Land met de Alpen en hagelslag op brood (nou ja, chocolade).",
        type: "choice",
        choices: ["Nederland", "Zwitserland", "Frankrijk", "Duitsland"],
        answer: "Zwitserland",
      },
      {
        id: "c2",
        title: "De draagtijd",
        image: img(19),
        digit: "9",
        briefing: [
          "Op een kalender zijn negen maanden rood omcirkeld.",
          "Een koe is ongeveer 9 maanden drachtig — precies even lang als een mens.",
        ],
        fact: "Een koe is ongeveer 9 maanden drachtig.",
        question: "Hoeveel maanden duurt de draagtijd van een koe?",
        hint: "Even lang als bij een mens.",
        type: "number",
        answer: "9",
      },
      {
        id: "c3",
        title: "Van kalf tot koe",
        image: img(21),
        digit: "3",
        briefing: [
          "Vier foto's hangen door elkaar aan het bord.",
          "De volgorde: KALF (pasgeboren) → PINK (jong) → VAARS (bijna volwassen) → KOE (heeft kalf gehad).",
        ],
        fact: "De vier stadia: kalf → pink → vaars → koe.",
        question: "Zet de stadia in volgorde van klein naar groot.",
        hint: "Het allerkleinste begint met een K.",
        type: "order",
        items: ["Koe", "Pink", "Kalf", "Vaars"],
        answer: ["Kalf", "Pink", "Vaars", "Koe"],
      },
      {
        id: "c4",
        title: "Het geboortegewicht",
        image: img(22),
        digit: "2",
        briefing: [
          "Een weegschaal in de stal piept op 40 kg.",
          "Een pasgeboren kalf weegt ongeveer 40 kilo — zo zwaar als een flinke hond.",
        ],
        fact: "Een pasgeboren kalf weegt ongeveer 40 kg.",
        question: "Hoeveel kilo weegt een pasgeboren kalf ongeveer?",
        hint: "Een rond getal tussen 30 en 50.",
        type: "number",
        answer: "40",
      },
      {
        id: "c5",
        title: "Hoe vaak melken?",
        image: img(23),
        digit: "6",
        briefing: [
          "Aan de muur hangt een dagschema: 's ochtends vroeg en 's avonds laat.",
          "Een melkkoe wordt meestal 2 keer per dag gemolken.",
        ],
        fact: "Een koe wordt meestal 2 keer per dag gemolken.",
        question: "Hoe vaak per dag wordt een koe meestal gemolken?",
        hint: "Niet één, niet drie...",
        type: "number",
        answer: "2",
      },
      {
        id: "c6",
        title: "Liters melk per dag",
        image: img(24),
        digit: "5",
        briefing: [
          "Een melktank vult zich tot precies 25 liter per koe per dag.",
          "Een gemiddelde melkkoe geeft ongeveer 25 liter melk per dag.",
        ],
        fact: "Een melkkoe geeft gemiddeld ongeveer 25 liter melk per dag.",
        question: "Hoeveel liter melk geeft een koe gemiddeld per dag?",
        hint: "Een kwart van honderd.",
        type: "number",
        answer: "25",
      },
      {
        id: "c7",
        title: "Het uier",
        image: img(25),
        digit: "4",
        briefing: [
          "Een tekening toont een uier van onderen, met de tepels duidelijk genummerd.",
          "Een uier heeft 4 tepels — eentje voor elk kwart.",
        ],
        fact: "Een uier heeft 4 tepels.",
        question: "Hoeveel tepels heeft het uier van een koe?",
        hint: "Net zo veel als poten.",
        type: "number",
        answer: "4",
      },
      {
        id: "c8",
        title: "Wat eet een koe?",
        image: img(26),
        digit: "1",
        briefing: [
          "Op een tafel staan drie bakjes: gras, hooi en kuilvoer.",
          "Een koe is een planteneter en eet vooral GRAS (in de wei) en hooi/kuilvoer in de stal.",
        ],
        fact: "Een koe eet vooral gras, hooi en kuilvoer.",
        question: "Wat eet een koe het allermeest?",
        hint: "Groen, groeit in de wei.",
        type: "choice",
        choices: ["Vlees", "Vis", "Gras", "Brood"],
        answer: "Gras",
      },
      {
        id: "c9",
        title: "De oudste koe",
        image: img(27),
        digit: "8",
        briefing: [
          "In een lijstje hangt een trotse foto: 'Onze oudste koe — 18 jaar.'",
          "Een koe wordt op een goede boerderij ongeveer 18 jaar oud.",
        ],
        fact: "De oudste koe op de boerderij van de spreekbeurt werd 18 jaar.",
        question: "Hoe oud werd de oudste koe op de boerderij?",
        hint: "Achttien — typ alleen het getal.",
        type: "number",
        answer: "18",
      },
      {
        id: "c10",
        title: "Direct op zijn pootjes",
        image: img(28),
        digit: "1",
        briefing: [
          "Een filmpje in je hoofd: een pasgeboren kalfje wankelt na een paar minuten al overeind.",
          "Binnen ongeveer 15 minuten (een kwartier) staat een gezond kalfje al op zijn pootjes.",
        ],
        fact: "Een kalfje staat binnen ongeveer 15 minuten al op zijn pootjes.",
        question: "Na hoeveel minuten staat een kalfje meestal al op zijn pootjes?",
        hint: "Een kwartier.",
        type: "number",
        answer: "15",
      },
    ],
  },
  {
    id: "lab",
    name: "Het Veelaboratorium",
    subtitle: "Kamer 3 • Geheime onderzoekskamer",
    emoji: "🔬",
    accent: "from-emerald-800/40 to-slate-900/50",
    puzzles: [
      {
        id: "l1",
        title: "Hoeveel magen?",
        image: img(29),
        digit: "4",
        briefing: [
          "Een poster toont een koe in doorsnede. Vier delen zijn rood gemarkeerd.",
          "Een koe heeft 4 magen: pens, netmaag, boekmaag en lebmaag.",
        ],
        fact: "Een koe heeft 4 magen.",
        question: "Hoeveel magen heeft een koe?",
        hint: "Meer dan jij, minder dan vijf.",
        type: "number",
        answer: "4",
      },
      {
        id: "l2",
        title: "De vier magen op volgorde",
        image: img(30),
        digit: "2",
        briefing: [
          "Op een laboratoriumkaart liggen vier kaartjes door elkaar.",
          "Eten gaat door de magen in deze volgorde: PENS → NETMAAG → BOEKMAAG → LEBMAAG.",
        ],
        fact: "Volgorde van de magen: pens, netmaag, boekmaag, lebmaag.",
        question: "Zet de magen in de juiste volgorde (eerst → laatst).",
        hint: "De 'echte' maag (lebmaag) is altijd als laatste.",
        type: "order",
        items: ["Boekmaag", "Lebmaag", "Pens", "Netmaag"],
        answer: ["Pens", "Netmaag", "Boekmaag", "Lebmaag"],
      },
      {
        id: "l3",
        title: "Wat is herkauwen?",
        image: img(31),
        digit: "7",
        briefing: [
          "Op het bord een tekening: een koe boert een prop voedsel weer omhoog en kauwt rustig verder.",
          "Herkauwen = het eten OPNIEUW kauwen, zodat het beter verteert.",
        ],
        fact: "Herkauwen is het opnieuw kauwen van eten dat al in de maag is geweest.",
        question: "Wat doet een koe als ze herkauwt?",
        hint: "Het zit in het woord zelf — HER-kauwen.",
        type: "choice",
        choices: [
          "Ze drinkt water",
          "Ze kauwt het eten opnieuw",
          "Ze slikt het in één keer door",
          "Ze geeft over",
        ],
        answer: "Ze kauwt het eten opnieuw",
      },
      {
        id: "l4",
        title: "De slokdarmsleuf",
        image: img(33),
        digit: "0",
        briefing: [
          "Een tekening van een kalfshals laat een tijdelijke buis zien.",
          "Bij een drinkend kalfje slaat de melk dankzij de SLOKDARMSLEUF de eerste 3 magen over en komt direct in de LEBMAAG.",
        ],
        fact: "Door de slokdarmsleuf komt melk direct in de lebmaag.",
        question: "In welke maag komt de melk van een kalfje direct terecht?",
        hint: "De 'echte' maag — begint met L.",
        type: "choice",
        choices: ["Pens", "Netmaag", "Boekmaag", "Lebmaag"],
        answer: "Lebmaag",
      },
      {
        id: "l5",
        title: "De allereerste melk",
        image: img(34),
        digit: "5",
        briefing: [
          "Een geel-romige fles staat op de werkbank, met label: 'eerste melk na de geboorte'.",
          "Die allereerste, dikke gele melk heet BIEST. Hij zit vol afweerstoffen.",
        ],
        fact: "Biest is de allereerste melk en zit vol afweerstoffen.",
        question: "Hoe heet de allereerste melk die een kalfje krijgt?",
        hint: "Vijf letters, begint met B.",
        type: "text",
        answer: ["biest", "de biest"],
      },
      {
        id: "l6",
        title: "Snel die biest!",
        image: img(35),
        digit: "2",
        briefing: [
          "Op een klok in het lab tikken de uren snel weg.",
          "Een kalfje moet binnen 2 uur na de geboorte zijn biest krijgen, anders werken de afweerstoffen niet meer goed.",
        ],
        fact: "Een kalf moet biest krijgen binnen 2 uur na de geboorte.",
        question: "Binnen hoeveel uur moet een kalf zijn eerste biest krijgen?",
        hint: "Heel weinig uren — minder dan een halve middag.",
        type: "number",
        answer: "2",
      },
      {
        id: "l7",
        title: "De lichaamstemperatuur",
        image: img(37),
        digit: "8",
        briefing: [
          "Een thermometer in het lab wijst 38,5 graden aan.",
          "Een gezonde koe heeft een lichaamstemperatuur rond de 38 °C — iets warmer dan een mens.",
        ],
        fact: "Een gezonde koe heeft ongeveer 38 °C lichaamstemperatuur.",
        question: "Hoeveel graden Celsius is een gezonde koe (afgerond op heel getal)?",
        hint: "Net iets meer dan een mens met koorts...",
        type: "number",
        answer: "38",
      },
      {
        id: "l8",
        title: "Het kruidenrecept",
        image: img(36),
        digit: "7",
        briefing: [
          "Een glazen pot met witgele bloemen staat op de werkbank. Label: 'bij diarree van kalveren'.",
          "KAMILLE verzacht de darm en remt ontsteking — al eeuwen het kruid bij kalverdiarree.",
        ],
        fact: "Kamille kalmeert de darm bij een kalf met diarree.",
        question: "Welk kruid verzacht de darm bij een kalf met diarree?",
        hint: "Witgele bloem, klinkt als een meisjesnaam.",
        type: "text",
        answer: ["kamille", "camille"],
      },
      {
        id: "l9",
        title: "Eikenbast",
        image: img(38),
        digit: "6",
        briefing: [
          "Een schaaltje met bruine schors. Een briefje: 'samentrekkend, indikkend'.",
          "EIKENBAST wordt gebruikt om de mest weer dikker te laten worden bij dunne ontlasting.",
        ],
        fact: "Eikenbast dikt de mest in bij diarree.",
        question: "Waar wordt eikenbast voor gebruikt bij een kalf?",
        hint: "Het zorgt dat dunne poep weer steviger wordt.",
        type: "choice",
        choices: [
          "Tegen koorts",
          "Tegen vliegen",
          "Om de mest in te dikken",
          "Om de melk te smaken",
        ],
        answer: "Om de mest in te dikken",
      },
      {
        id: "l10",
        title: "Gras, gras, gras",
        image: img(39),
        digit: "3",
        briefing: [
          "Een grote weegschaal vol vers gras tikt 70 kg aan.",
          "Een volwassen koe eet wel zo'n 70 kg gras en voer per dag — daarom is ze ook zo groot.",
        ],
        fact: "Een koe eet wel zo'n 70 kg gras/voer per dag.",
        question: "Hoeveel kilo gras en voer eet een koe ongeveer per dag?",
        hint: "Een rond getal, iets meer dan een mens weegt.",
        type: "number",
        answer: "70",
      },
    ],
  },
];

// Sorteer puzzels binnen elke kamer op afbeelding-nummer, zodat de dia's
// in de juiste volgorde van de spreekbeurt verschijnen.
function imgNum(src: string): number {
  const m = src.match(/image(\d+)\./);
  return m ? parseInt(m[1], 10) : 0;
}
ROOMS.forEach((r) => r.puzzles.sort((a, b) => imgNum(a.image) - imgNum(b.image)));

export const ALL_PUZZLES = ROOMS.flatMap((r) => r.puzzles);
export const TOTAL_PUZZLES = ALL_PUZZLES.length;

// Eindkluis: alleen de cijfers van de LAATSTE 7 raadsels zijn nodig.
export const CODE_LENGTH = 7;
export const CODE_PUZZLES = ALL_PUZZLES.slice(-CODE_LENGTH);
export const FINAL_CODE = CODE_PUZZLES.map((p) => p.digit).join("");
