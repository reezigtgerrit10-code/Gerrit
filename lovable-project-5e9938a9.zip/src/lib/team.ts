// Team realtime channel: 1 leader + tot 5 joiners delen een 4-letter code.
// Gebruikt Supabase Realtime presence (members) + broadcast (game state + screen).

import { useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { RealtimeChannel } from "@supabase/supabase-js";

export type TeamMember = {
  id: string;
  name: string;
  isLeader: boolean;
  joinedAt: number;
};

export type TeamIdentity = {
  code: string;
  me: TeamMember;
  solo?: boolean;
};

export type ScreenFrame = {
  fromId: string;
  fromName: string;
  dataUrl: string;
  ts: number;
};

const TEAM_KEY = "escape-room:team";

const CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
export function generateTeamCode(len = 4): string {
  let out = "";
  for (let i = 0; i < len; i++) {
    out += CODE_ALPHABET[Math.floor(Math.random() * CODE_ALPHABET.length)];
  }
  return out;
}

export function newMemberId(): string {
  return Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
}

export function loadTeam(): TeamIdentity | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(TEAM_KEY);
    return raw ? (JSON.parse(raw) as TeamIdentity) : null;
  } catch {
    return null;
  }
}

export function saveTeam(t: TeamIdentity | null) {
  if (typeof window === "undefined") return;
  if (t) localStorage.setItem(TEAM_KEY, JSON.stringify(t));
  else localStorage.removeItem(TEAM_KEY);
}

export const MAX_MEMBERS = 5;

export function useTeamChannel({
  team,
  onIncomingState,
  onIncomingScreen,
}: {
  team: TeamIdentity | null;
  onIncomingState?: (state: unknown, fromId: string) => void;
  onIncomingScreen?: (frame: ScreenFrame) => void;
}) {
  const [members, setMembers] = useState<TeamMember[]>([]);
  const [ready, setReady] = useState(false);
  const channelRef = useRef<RealtimeChannel | null>(null);
  const stateCb = useRef(onIncomingState);
  const screenCb = useRef(onIncomingScreen);
  stateCb.current = onIncomingState;
  screenCb.current = onIncomingScreen;

  useEffect(() => {
    if (!team || team.solo) {
      setMembers(team?.solo ? [team.me] : []);
      setReady(!!team?.solo);
      return;
    }
    const ch = supabase.channel(`team:${team.code}`, {
      config: { presence: { key: team.me.id }, broadcast: { self: false } },
    });
    channelRef.current = ch;

    ch.on("presence", { event: "sync" }, () => {
      const ps = ch.presenceState() as Record<string, TeamMember[]>;
      const list: TeamMember[] = [];
      Object.values(ps).forEach((arr) => arr.forEach((m) => list.push(m)));
      list.sort((a, b) => {
        if (a.isLeader !== b.isLeader) return a.isLeader ? -1 : 1;
        return a.joinedAt - b.joinedAt;
      });
      setMembers(list);
    });

    ch.on("broadcast", { event: "state" }, (payload) => {
      const data = payload.payload as { state: unknown; fromId: string };
      stateCb.current?.(data.state, data.fromId);
    });

    ch.on("broadcast", { event: "screen" }, (payload) => {
      screenCb.current?.(payload.payload as ScreenFrame);
    });

    ch.subscribe(async (status) => {
      if (status === "SUBSCRIBED") {
        if (team.me) await ch.track(team.me);
        setReady(true);
      }
    });

    return () => {
      setReady(false);
      supabase.removeChannel(ch);
      channelRef.current = null;
    };
  }, [team?.code, team?.me.id, team?.solo]);

  function broadcastState(state: unknown) {
    const ch = channelRef.current;
    if (!ch || !team || team.solo) return;
    ch.send({
      type: "broadcast",
      event: "state",
      payload: { state, fromId: team.me.id },
    });
  }

  function broadcastScreen(frame: ScreenFrame) {
    const ch = channelRef.current;
    if (!ch || !team || team.solo) return;
    ch.send({ type: "broadcast", event: "screen", payload: frame });
  }

  return { members, ready, broadcastState, broadcastScreen };
}

/**
 * Host-only: luister naar één team-kanaal als kijker (zonder presence).
 */
export function useHostChannel({
  code,
  onState,
  onScreen,
}: {
  code: string | null;
  onState: (state: unknown, fromId: string) => void;
  onScreen: (frame: ScreenFrame) => void;
}) {
  const [connected, setConnected] = useState(false);
  const stateCb = useRef(onState);
  const screenCb = useRef(onScreen);
  stateCb.current = onState;
  screenCb.current = onScreen;

  useEffect(() => {
    if (!code) {
      setConnected(false);
      return;
    }
    const ch = supabase.channel(`team:${code}`, {
      config: { broadcast: { self: false } },
    });
    ch.on("broadcast", { event: "state" }, (p) => {
      const d = p.payload as { state: unknown; fromId: string };
      stateCb.current(d.state, d.fromId);
    });
    ch.on("broadcast", { event: "screen" }, (p) => {
      screenCb.current(p.payload as ScreenFrame);
    });
    ch.subscribe((s) => setConnected(s === "SUBSCRIBED"));
    return () => {
      supabase.removeChannel(ch);
      setConnected(false);
    };
  }, [code]);

  return { connected };
}

/**
 * Hook: start scherm delen via getDisplayMedia en stuur ~1 fps JPEG naar het team-kanaal.
 */
export function useScreenShare(
  broadcast: (f: ScreenFrame) => void,
  me: TeamMember | null,
) {
  const [sharing, setSharing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const intervalRef = useRef<number | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);

  async function start() {
    if (sharing || !me) return;
    setError(null);
    try {
      const stream = await navigator.mediaDevices.getDisplayMedia({
        video: { frameRate: 4 },
        audio: false,
      });
      streamRef.current = stream;
      const v = document.createElement("video");
      v.srcObject = stream;
      v.muted = true;
      await v.play();
      videoRef.current = v;

      stream.getVideoTracks()[0].addEventListener("ended", () => stop());

      intervalRef.current = window.setInterval(() => {
        const vid = videoRef.current;
        if (!vid || vid.videoWidth === 0) return;
        const w = 640;
        const h = Math.round((vid.videoHeight / vid.videoWidth) * w);
        const canvas = document.createElement("canvas");
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext("2d");
        if (!ctx) return;
        ctx.drawImage(vid, 0, 0, w, h);
        const dataUrl = canvas.toDataURL("image/jpeg", 0.5);
        broadcast({ fromId: me.id, fromName: me.name, dataUrl, ts: Date.now() });
      }, 1500);

      setSharing(true);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Kon scherm niet delen");
    }
  }

  function stop() {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    videoRef.current = null;
    setSharing(false);
  }

  useEffect(() => () => stop(), []);

  return { sharing, error, start, stop };
}
