// Shared game state for the escape room.
// Persists in localStorage so a presenter tab on the same device (or screen-share)
// can read live progress via `storage` events and BroadcastChannel.

export type GameStage = "lobby" | "intro" | "playing" | "vault" | "victory";

export type GameState = {
  stage: GameStage;
  roomIdx: number;
  puzzleIdx: number;
  solvedIds: string[];
  digits: Record<string, string>; // puzzleId -> digit
  startedAt: number | null;
  elapsed: number;
  wrongAttempts: number;
  hintsUsed: string[];
  lastEvent: string;
  updatedAt: number;
};

export const INITIAL_STATE: GameState = {
  stage: "lobby",
  roomIdx: 0,
  puzzleIdx: 0,
  solvedIds: [],
  digits: {},
  startedAt: null,
  elapsed: 0,
  wrongAttempts: 0,
  hintsUsed: [],
  lastEvent: "Wacht op team",
  updatedAt: Date.now(),
};

const KEY = "escape-room:state";
const CHANNEL = "escape-room:channel";

export function loadState(): GameState | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(KEY);
    return raw ? (JSON.parse(raw) as GameState) : null;
  } catch {
    return null;
  }
}

export function saveState(s: GameState) {
  if (typeof window === "undefined") return;
  const payload = { ...s, updatedAt: Date.now() };
  localStorage.setItem(KEY, JSON.stringify(payload));
  try {
    const bc = new BroadcastChannel(CHANNEL);
    bc.postMessage(payload);
    bc.close();
  } catch {
    // ignore
  }
}

export function subscribe(cb: (s: GameState) => void): () => void {
  if (typeof window === "undefined") return () => {};
  const onStorage = (e: StorageEvent) => {
    if (e.key === KEY && e.newValue) {
      try {
        cb(JSON.parse(e.newValue));
      } catch {
        // ignore
      }
    }
  };
  window.addEventListener("storage", onStorage);
  let bc: BroadcastChannel | null = null;
  try {
    bc = new BroadcastChannel(CHANNEL);
    bc.onmessage = (ev) => cb(ev.data as GameState);
  } catch {
    // ignore
  }
  return () => {
    window.removeEventListener("storage", onStorage);
    bc?.close();
  };
}
