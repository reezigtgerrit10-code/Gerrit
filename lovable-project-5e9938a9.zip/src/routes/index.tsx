import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { speakText } from "@/lib/tts.functions";
import {
  type GameState,
  INITIAL_STATE,
  loadState,
  saveState,
} from "@/lib/gameState";
import {
  ROOMS,
  TOTAL_PUZZLES,
  CODE_PUZZLES,
  type Puzzle,
} from "@/lib/puzzles";
import {
  type TeamIdentity,
  type TeamMember,
  MAX_MEMBERS,
  generateTeamCode,
  loadTeam,
  newMemberId,
  saveTeam,
  useTeamChannel,
  useScreenShare,
} from "@/lib/team";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Dieren Escape Room — Spreekbeurt" },
      {
        name: "description",
        content:
          "Een spannende escape room over herten, kalveren en hun spijsvertering. Los alle raadsels op, verzamel cijfers en kraak de kluis.",
      },
      { property: "og:title", content: "Dieren Escape Room" },
      {
        property: "og:description",
        content:
          "Interactieve spreekbeurt-escape-room voor 12–13 jarigen: missievideo, AI-verteller en geheime code.",
      },
    ],
  }),
  component: EscapeRoom,
});

/* ============================================================
   ROOT
   ============================================================ */

function EscapeRoom() {
  const [state, setState] = useState<GameState>(() => loadState() ?? INITIAL_STATE);
  const [elapsed, setElapsed] = useState(0);

  // persist on every change
  useEffect(() => {
    saveState({ ...state, elapsed });
  }, [state, elapsed]);

  // identity for team (persistent local)
  const [team, setTeam] = useState<TeamIdentity | null>(() => loadTeam());
  useEffect(() => {
    saveTeam(team);
  }, [team]);

  // realtime team channel — broadcasts state to peers, merges incoming
  const lastBroadcastRef = useRef<number>(0);
  const onIncomingState = useCallback((incoming: unknown) => {
    const s = incoming as GameState;
    if (!s || typeof s.updatedAt !== "number") return;
    setState((cur) => (s.updatedAt > cur.updatedAt ? s : cur));
  }, []);
  const { members, ready: channelReady, broadcastState, broadcastScreen } = useTeamChannel({
    team,
    onIncomingState,
  });
  const screen = useScreenShare(broadcastScreen, team?.me ?? null);

  // broadcast my state changes to teammates
  useEffect(() => {
    if (!team || !channelReady) return;
    if (state.updatedAt === lastBroadcastRef.current) return;
    lastBroadcastRef.current = state.updatedAt;
    broadcastState(state);
  }, [state, team, channelReady, broadcastState]);

  // timer
  useEffect(() => {
    if (!state.startedAt) return;
    const t = setInterval(
      () => setElapsed(Math.floor((Date.now() - state.startedAt!) / 1000)),
      1000,
    );
    return () => clearInterval(t);
  }, [state.startedAt]);

  const currentRoom = ROOMS[state.roomIdx];
  const currentPuzzle = currentRoom?.puzzles[state.puzzleIdx];

  function update(patch: Partial<GameState>, ev?: string) {
    setState((s) => ({ ...s, ...patch, lastEvent: ev ?? s.lastEvent }));
  }

  function startGame() {
    update(
      { stage: "playing", startedAt: Date.now(), lastEvent: "🚀 Spel gestart" },
      "🚀 Spel gestart",
    );
  }

  function onSolved(p: Puzzle) {
    setState((s) => {
      const solvedIds = s.solvedIds.includes(p.id) ? s.solvedIds : [...s.solvedIds, p.id];
      const digits = { ...s.digits, [p.id]: p.digit };
      // advance
      let roomIdx = s.roomIdx;
      let puzzleIdx = s.puzzleIdx;
      let stage: GameState["stage"] = s.stage;
      if (puzzleIdx + 1 < ROOMS[roomIdx].puzzles.length) {
        puzzleIdx += 1;
      } else if (roomIdx + 1 < ROOMS.length) {
        roomIdx += 1;
        puzzleIdx = 0;
      } else {
        stage = "vault";
      }
      return {
        ...s,
        solvedIds,
        digits,
        roomIdx,
        puzzleIdx,
        stage,
        lastEvent: `✓ ${p.title} opgelost — cijfer ${p.digit}`,
      };
    });
  }

  function onWrong(p: Puzzle) {
    setState((s) => ({
      ...s,
      wrongAttempts: s.wrongAttempts + 1,
      lastEvent: `✗ Fout antwoord bij "${p.title}"`,
    }));
  }

  function onHint(p: Puzzle) {
    setState((s) =>
      s.hintsUsed.includes(p.id)
        ? s
        : { ...s, hintsUsed: [...s.hintsUsed, p.id], lastEvent: `💡 Hint gebruikt bij "${p.title}"` },
    );
  }

  function onVaultSolved() {
    update({ stage: "victory", lastEvent: "🏆 Kluis open! Ontsnapt!" });
  }

  function restart() {
    const fresh: GameState = { ...INITIAL_STATE, updatedAt: Date.now() };
    setState(fresh);
    setElapsed(0);
  }

  function leaveTeam() {
    setTeam(null);
    setState({ ...INITIAL_STATE, updatedAt: Date.now() });
    setElapsed(0);
  }

  function startMission() {
    update({ stage: "intro", lastEvent: "🎬 Missie-briefing gestart" }, "🎬 Missie-briefing gestart");
  }

  // gate: no team yet → choose create/join
  if (!team) {
    return (
      <main className="relative min-h-screen overflow-hidden vignette">
        <AmbientFog />
        <Particles />
        <TeamGate
          onCreated={(t) => {
            setTeam(t);
            // Solo? Sla lobby over en ga direct naar de missie-briefing.
            setState({
              ...INITIAL_STATE,
              stage: t.solo ? "intro" : "lobby",
              updatedAt: Date.now(),
            });
          }}
        />
      </main>
    );
  }

  return (
    <main className="relative min-h-screen overflow-hidden vignette">
      <AmbientFog />
      <Particles />

      <header className="relative z-10 mx-auto flex max-w-6xl items-center justify-between px-6 py-5">
        <div className="flex items-center gap-3">
          <div className="text-3xl flicker">🔐</div>
          <div>
            <div className="text-xs uppercase tracking-[0.3em] text-primary/80">
              Team {team.code} · {team.me.name}{team.me.isLeader ? " (leider)" : ""}
            </div>
            <div className="font-display text-xl text-foreground">Dieren Escape Room</div>
          </div>
        </div>
        <div className="flex items-center gap-3">
          {state.stage !== "intro" && state.stage !== "lobby" && (
            <>
              <Stat label="Tijd" value={formatTime(elapsed)} />
              <Stat
                label="Cijfers"
                value={`${Object.keys(state.digits).length} / ${TOTAL_PUZZLES}`}
              />
            </>
          )}
          <Stat label="Team" value={`${members.length}/${MAX_MEMBERS}`} />
          <button
            onClick={() => (screen.sharing ? screen.stop() : screen.start())}
            className={`rounded-lg border px-3 py-1.5 text-xs uppercase tracking-widest transition ${
              screen.sharing
                ? "border-accent bg-accent/20 text-accent animate-pulse"
                : "border-border bg-card/60 text-foreground/70 hover:border-primary/60 hover:text-primary"
            }`}
            title="Deel je scherm met de presentator"
          >
            {screen.sharing ? "🔴 Delen aan" : "📺 Deel scherm"}
          </button>
          <button
            onClick={leaveTeam}
            className="rounded-lg border border-border bg-card/60 px-3 py-1.5 text-xs uppercase tracking-widest text-foreground/70 hover:border-destructive/60 hover:text-destructive"
            title="Team verlaten"
          >
            ⎋ Verlaat
          </button>
          <a
            href={`/host?code=${team.code}`}
            target="_blank"
            rel="noreferrer"
            className="rounded-lg border border-border bg-card/60 px-3 py-1.5 text-xs uppercase tracking-widest text-foreground/70 hover:border-primary/60 hover:text-primary"
          >
            🎬 Presentator
          </a>
        </div>
      </header>

      <section className="relative z-10 mx-auto max-w-5xl px-6 pb-24">
        {state.stage === "lobby" && (
          <Lobby
            team={team}
            members={members}
            channelReady={channelReady}
            onStart={startMission}
          />
        )}
        {state.stage === "intro" && <Intro onStart={startGame} />}
        {state.stage === "playing" && currentPuzzle && (
          <PuzzleView
            key={currentPuzzle.id}
            room={currentRoom}
            puzzle={currentPuzzle}
            roomIdx={state.roomIdx}
            puzzleIdx={state.puzzleIdx}
            onSolved={() => onSolved(currentPuzzle)}
            onWrong={() => onWrong(currentPuzzle)}
            onHint={() => onHint(currentPuzzle)}
          />
        )}
        {state.stage === "vault" && (
          <Vault digits={state.digits} onSolved={onVaultSolved} />
        )}
        {state.stage === "victory" && (
          <Victory time={elapsed} digits={state.digits} onRestart={restart} />
        )}
      </section>
    </main>
  );
}

/* ============================================================
   INTRO — cinematische missie-video met AI-stem en prijs
   ============================================================ */

const MISSION_SCRIPT = [
  "Welkom, agent. Het is twee uur 's nachts. Je bent per ongeluk opgesloten in het geheime Dierenmuseum.",
  "De directeur — een excentrieke professor — heeft drie kamers vergrendeld. Het Hertenbos, de Kalverstal, en zijn geheime Veelaboratorium.",
  "In elke kamer wachten drie raadsels. Bij elk goed antwoord vind je een geheim CIJFER. Negen cijfers samen openen de eindkluis.",
  "In de kluis ligt de GOUDEN DIERENSLEUTEL, een diploma met jouw naam erop, én de eer om de slimste dierenkenner van de klas te zijn.",
  "Klaar? De klok tikt. Veel succes — en denk goed na voor je antwoordt.",
];

function Intro({ onStart }: { onStart: () => void }) {
  const [step, setStep] = useState(-1); // -1 = cover, 0..n = mission slides
  const narration = useNarration();

  useEffect(() => {
    if (step < 0 || step >= MISSION_SCRIPT.length) return;
    narration.play(MISSION_SCRIPT[step]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [step]);

  useEffect(() => () => narration.stop(), []); // eslint-disable-line

  if (step === -1) {
    return (
      <div className="mt-12 text-center">
        <div className="mb-6 inline-block float-slow text-8xl">🦌🐄🔬</div>
        <h1 className="font-display text-5xl md:text-7xl text-foreground leading-tight">
          Ontsnap uit het <span className="text-primary flicker">Dierenmuseum</span>
        </h1>
        <p className="mx-auto mt-6 max-w-2xl text-lg text-foreground/80 leading-relaxed">
          Een spannende escape room over herten, kalveren en hun geheime spijsvertering.
          Voor jou en je klasgenoten van 12–13 jaar.
        </p>

        <div className="mt-10 grid gap-4 md:grid-cols-3">
          {ROOMS.map((r, i) => (
            <div key={r.id} className={`rounded-2xl border border-border bg-gradient-to-br ${r.accent} p-6 backdrop-blur-sm`}>
              <div className="text-5xl mb-2">{r.emoji}</div>
              <div className="font-display text-2xl">{r.name}</div>
              <div className="text-sm text-foreground/70">{r.subtitle}</div>
              <div className="mt-3 text-xs uppercase tracking-widest text-primary/80">
                Kamer {i + 1} • {r.puzzles.length} raadsels
              </div>
            </div>
          ))}
        </div>

        <button
          onClick={() => setStep(0)}
          className="mt-12 rounded-full bg-primary px-10 py-4 font-display text-xl text-background glow-pulse transition hover:scale-105"
        >
          🎬 Speel de missie-video
        </button>
        <p className="mt-4 text-xs text-foreground/50">
          Tip voor de presentator: open in een nieuw tabblad{" "}
          <code className="text-primary">/host</code> om live mee te kijken.
        </p>
      </div>
    );
  }

  const line = MISSION_SCRIPT[step];
  const isLast = step >= MISSION_SCRIPT.length - 1;

  return (
    <div className="mt-8 animate-in fade-in zoom-in-95 duration-500">
      <div className="mb-3 flex items-center justify-between text-xs uppercase tracking-[0.3em] text-primary/80">
        <span>🎬 Missie-briefing</span>
        <span>
          Scène {step + 1} / {MISSION_SCRIPT.length}
        </span>
      </div>

      {/* Cinematic frame */}
      <div className="relative aspect-video overflow-hidden rounded-3xl border-2 border-primary/40 bg-black shadow-[0_0_60px_-10px_var(--primary)]">
        {/* animated background */}
        <CinematicBackdrop step={step} />
        {/* film grain */}
        <div className="absolute inset-0 opacity-[0.08] mix-blend-overlay" style={{
          backgroundImage:
            "url(\"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='200' height='200'><filter id='n'><feTurbulence baseFrequency='0.9'/></filter><rect width='100%' height='100%' filter='url(%23n)' opacity='0.6'/></svg>\")",
        }} />
        {/* letterbox bars */}
        <div className="absolute inset-x-0 top-0 h-10 bg-black" />
        <div className="absolute inset-x-0 bottom-0 h-10 bg-black" />

        {/* big emoji actor */}
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-[14rem] opacity-90 animate-in zoom-in duration-1000" key={step}>
            {["🌒", "🦌", "🐄", "🔑", "🏆"][step] ?? "🎬"}
          </div>
        </div>

        {/* subtitles */}
        <div className="absolute inset-x-6 bottom-14 md:inset-x-16">
          <div key={step} className="paper rounded-xl p-4 md:p-5 text-sm md:text-lg leading-relaxed animate-in slide-in-from-bottom-2 fade-in duration-500">
            {line}
            {narration.state === "playing" && (
              <div className="mt-3 flex h-3 items-end gap-1">
                {[0, 1, 2, 3, 4].map((i) => (
                  <span
                    key={i}
                    className="w-1.5 rounded-full bg-primary"
                    style={{ animation: `audio-bar 0.9s ${i * 0.12}s ease-in-out infinite`, height: "40%" }}
                  />
                ))}
              </div>
            )}
          </div>
        </div>

        {/* badge */}
        <div className="absolute left-4 top-3 flex items-center gap-2 text-[10px] uppercase tracking-[0.3em] text-primary">
          <span className="h-2 w-2 rounded-full bg-red-500 animate-pulse" /> Live missie
        </div>
      </div>

      <div className="mt-5 flex flex-wrap items-center justify-between gap-3">
        <div className="flex gap-1.5">
          {MISSION_SCRIPT.map((_, i) => (
            <div
              key={i}
              className={`h-1.5 w-10 rounded-full transition-all ${i <= step ? "bg-primary" : "bg-border"}`}
            />
          ))}
        </div>
        <div className="flex gap-2">
          <NarrationControls n={narration} text={line} />
          <button
            onClick={() => setStep(Math.max(0, step - 1))}
            disabled={step === 0}
            className="rounded-xl border border-border px-4 py-2 text-sm disabled:opacity-30"
          >
            ← Terug
          </button>
          {!isLast ? (
            <button
              onClick={() => setStep(step + 1)}
              className="rounded-xl bg-primary/80 px-5 py-2 font-bold text-background transition hover:scale-105"
            >
              Verder →
            </button>
          ) : (
            <button
              onClick={() => {
                narration.stop();
                onStart();
              }}
              className="rounded-xl bg-primary px-6 py-2 font-display text-lg text-background glow-pulse transition hover:scale-105"
            >
              🔓 Start de escape!
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

function CinematicBackdrop({ step }: { step: number }) {
  const palettes = [
    "from-slate-900 via-indigo-950 to-black", // nacht
    "from-emerald-950 via-amber-900/40 to-slate-900", // bos
    "from-amber-900/40 via-yellow-900/30 to-stone-900", // stal
    "from-fuchsia-900/40 via-primary/30 to-black", // sleutel
    "from-yellow-700/40 via-primary/40 to-amber-900/30", // goud
  ];
  return (
    <div className={`absolute inset-0 bg-gradient-to-br ${palettes[step] ?? palettes[0]} transition-all duration-1000`}>
      <div className="absolute inset-0 opacity-40" style={{
        background: "radial-gradient(circle at 30% 40%, rgba(255,255,255,0.15), transparent 50%)",
      }} />
    </div>
  );
}

/* ============================================================
   PUZZLE VIEW
   ============================================================ */

function PuzzleView({
  room,
  puzzle,
  roomIdx,
  puzzleIdx,
  onSolved,
  onWrong,
  onHint,
}: {
  room: (typeof ROOMS)[number];
  puzzle: Puzzle;
  roomIdx: number;
  puzzleIdx: number;
  onSolved: () => void;
  onWrong: () => void;
  onHint: () => void;
}) {
  const [phase, setPhase] = useState<"briefing" | "puzzle">("briefing");
  const [briefStep, setBriefStep] = useState(0);
  const [value, setValue] = useState("");
  const [order, setOrder] = useState<string[]>(puzzle.items ?? []);
  const [wrong, setWrong] = useState(false);
  const [revealed, setRevealed] = useState(false);
  const [wasWrong, setWasWrong] = useState(false);
  const [showHint, setShowHint] = useState(false);
  const [unlocking, setUnlocking] = useState(false);

  const narration = useNarration();

  useEffect(() => {
    if (phase !== "briefing") {
      narration.stop();
      return;
    }
    narration.play(puzzle.briefing[briefStep]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phase, briefStep, puzzle.id]);

  useEffect(() => () => narration.stop(), []); // eslint-disable-line

  function check() {
    let ok = false;
    if (puzzle.type === "order") {
      ok = JSON.stringify(order) === JSON.stringify(puzzle.answer);
    } else {
      const norm = value.trim().toLowerCase();
      const ans = puzzle.answer;
      ok = Array.isArray(ans) ? ans.some((a) => a.toLowerCase() === norm) : ans.toLowerCase() === norm;
    }
    if (ok) {
      setRevealed(true);
      setUnlocking(true);
      setTimeout(() => onSolved(), 3200);
    } else {
      onWrong();
      setWrong(true);
      setWasWrong(true);
      setRevealed(true);
      setUnlocking(true);
      setTimeout(() => setWrong(false), 600);
      setTimeout(() => onSolved(), 4200);
    }
  }

  function toggleHint() {
    setShowHint((s) => {
      if (!s) onHint();
      return !s;
    });
  }

  if (phase === "briefing") {
    const last = briefStep >= puzzle.briefing.length - 1;
    return (
      <div className="mt-6 animate-in fade-in slide-in-from-bottom-4 duration-700">
        <div className="mb-4 flex items-center justify-between text-xs uppercase tracking-[0.3em] text-primary/80">
          <span>
            {room.emoji} {room.name}
          </span>
          <span>
            📖 Onderzoek • Raadsel {puzzleIdx + 1} / {room.puzzles.length}
          </span>
        </div>
        <div className="grid gap-6 rounded-3xl border border-border bg-card/70 p-6 backdrop-blur-md md:grid-cols-2">
          <div className="relative overflow-hidden rounded-2xl border border-border">
            <img
              src={puzzle.image}
              alt={puzzle.title}
              className="h-72 w-full object-cover md:h-full"
              onError={(e) => ((e.currentTarget as HTMLImageElement).style.display = "none")}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-card/80 to-transparent" />
            <div className="absolute bottom-4 left-4 right-4 font-display text-2xl">{puzzle.title}</div>
          </div>
          <div className="flex flex-col justify-between">
            <div>
              <div className="mb-3 flex items-center justify-between">
                <div className="inline-block rounded-full bg-primary/20 px-3 py-1 text-xs uppercase tracking-widest text-primary">
                  🎙️ De Verteller{" "}
                  {narration.state === "loading"
                    ? "denkt na…"
                    : narration.state === "playing"
                      ? "praat"
                      : "wacht"}
                </div>
                <NarrationControls n={narration} text={puzzle.briefing[briefStep]} />
              </div>
              <div className="paper rounded-xl p-6 text-base leading-relaxed min-h-[200px]">
                <div key={briefStep} className="animate-in fade-in slide-in-from-right-4 duration-500">
                  {puzzle.briefing[briefStep]}
                </div>
                {narration.state === "playing" && (
                  <div className="mt-4 flex h-5 items-end gap-1">
                    {[0, 1, 2, 3, 4].map((i) => (
                      <span
                        key={i}
                        className="w-1.5 rounded-full bg-primary"
                        style={{ animation: `audio-bar 0.9s ${i * 0.12}s ease-in-out infinite`, height: "40%" }}
                      />
                    ))}
                  </div>
                )}
              </div>
              <div className="mt-3 flex gap-1.5">
                {puzzle.briefing.map((_, i) => (
                  <div
                    key={i}
                    className={`h-1.5 flex-1 rounded-full transition-all ${i <= briefStep ? "bg-primary" : "bg-border"}`}
                  />
                ))}
              </div>
            </div>
            <div className="mt-6 flex items-center justify-between gap-3">
              <button
                onClick={() => setBriefStep(Math.max(0, briefStep - 1))}
                disabled={briefStep === 0}
                className="rounded-xl border border-border px-4 py-3 text-sm disabled:opacity-30"
              >
                ← Terug
              </button>
              {!last ? (
                <button
                  onClick={() => setBriefStep(briefStep + 1)}
                  className="rounded-xl bg-primary/80 px-6 py-3 font-bold text-background transition hover:scale-105"
                >
                  Verder lezen →
                </button>
              ) : (
                <button
                  onClick={() => {
                    narration.stop();
                    setPhase("puzzle");
                  }}
                  className="rounded-xl bg-primary px-6 py-3 font-display text-lg text-background glow-pulse transition hover:scale-105"
                >
                  🔑 Naar het raadsel
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="mt-6 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="mb-4 flex items-center justify-between text-xs uppercase tracking-[0.3em] text-primary/80">
        <span>
          {room.emoji} {room.name}
        </span>
        <span>
          Raadsel {puzzleIdx + 1} / {room.puzzles.length}
        </span>
      </div>

      <div
        className={`grid gap-6 rounded-3xl border border-border bg-card/70 p-6 backdrop-blur-md md:grid-cols-2 ${wrong ? "animate-[shake_0.5s]" : ""}`}
      >
        <div className="relative overflow-hidden rounded-2xl border border-border">
          <img
            src={puzzle.image}
            alt={puzzle.title}
            className="h-72 w-full object-cover md:h-full"
            onError={(e) => ((e.currentTarget as HTMLImageElement).style.display = "none")}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-card/90 to-transparent" />
          <div className="absolute bottom-4 left-4 right-4">
            <div className="font-display text-2xl">{puzzle.title}</div>
          </div>
          {unlocking && (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-accent/30 backdrop-blur-sm">
              <div className="text-7xl" style={{ animation: "unlock 1.5s ease-out forwards" }}>
                🔓
              </div>
              <div className="rounded-2xl border-4 border-primary bg-background/90 px-8 py-4 shadow-[0_0_40px_var(--primary)]"
                   style={{ animation: "scale-in 0.6s 0.3s both" }}>
                <div className="text-[10px] uppercase tracking-[0.3em] text-primary/80">Geheim cijfer</div>
                <div className="font-display text-7xl text-primary">{puzzle.digit}</div>
              </div>
            </div>
          )}
        </div>

        <div>
          <h2 className="font-display text-3xl text-primary">{puzzle.question}</h2>

          {revealed && (
            <div
              className={`mt-4 rounded-xl border p-4 text-sm leading-relaxed animate-in fade-in zoom-in-95 ${
                wasWrong
                  ? "border-amber-500/50 bg-amber-500/10"
                  : "border-accent/40 bg-accent/10"
              }`}
            >
              <div className={`mb-1 font-bold ${wasWrong ? "text-amber-400" : "text-accent"}`}>
                {wasWrong ? "✗ Niet juist — maar geen zorgen!" : "✓ Goed! Onthoud het cijfer."}
              </div>
              {wasWrong && (
                <div className="mb-2">
                  Het juiste antwoord was:{" "}
                  <strong className="text-foreground">
                    {puzzle.type === "order"
                      ? (puzzle.answer as string[]).join(" → ")
                      : Array.isArray(puzzle.answer)
                        ? puzzle.answer[0]
                        : puzzle.answer}
                  </strong>
                  . Je krijgt het cijfer toch — door naar het volgende raadsel!
                </div>
              )}
              {puzzle.fact}
            </div>
          )}

          {!revealed && (
            <>
              <div className="mt-6">
                {puzzle.type === "choice" && (
                  <div className="grid grid-cols-2 gap-3">
                    {puzzle.choices!.map((c) => (
                      <button
                        key={c}
                        onClick={() => setValue(c)}
                        className={`rounded-xl border-2 px-4 py-4 text-lg transition ${
                          value === c
                            ? "border-primary bg-primary/20 text-primary"
                            : "border-border bg-muted/40 hover:border-primary/60"
                        }`}
                      >
                        {c}
                      </button>
                    ))}
                  </div>
                )}

                {(puzzle.type === "text" || puzzle.type === "number") && (
                  <input
                    autoFocus
                    type={puzzle.type === "number" ? "number" : "text"}
                    value={value}
                    onChange={(e) => setValue(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && check()}
                    placeholder="Typ je antwoord…"
                    className="w-full rounded-xl border-2 border-border bg-muted/40 px-5 py-4 text-xl text-foreground placeholder:text-foreground/30 focus:border-primary focus:outline-none"
                  />
                )}

                {puzzle.type === "order" && <OrderPuzzle items={order} setItems={setOrder} />}
              </div>

              <div className="mt-6 flex flex-wrap items-center gap-3">
                <button
                  onClick={check}
                  className="rounded-xl bg-primary px-6 py-3 font-bold text-background transition hover:scale-105 disabled:opacity-50"
                  disabled={puzzle.type !== "order" && !value}
                >
                  🔑 Probeer
                </button>
                <button
                  onClick={toggleHint}
                  className="rounded-xl border border-border px-4 py-3 text-sm text-foreground/80 hover:border-primary/60"
                >
                  💡 Hint
                </button>
                {wrong && <span className="text-sm text-destructive">Niet juist… probeer opnieuw!</span>}
              </div>

              {showHint && (
                <p className="mt-4 rounded-lg border border-dashed border-primary/40 bg-primary/5 p-3 text-sm italic text-foreground/80">
                  {puzzle.hint}
                </p>
              )}
            </>
          )}
        </div>
      </div>

      <ProgressDots roomIdx={roomIdx} puzzleIdx={puzzleIdx} />
    </div>
  );
}

function ProgressDots({ roomIdx, puzzleIdx }: { roomIdx: number; puzzleIdx: number }) {
  return (
    <div className="mt-6 flex justify-center gap-2">
      {ROOMS.flatMap((r, ri) =>
        r.puzzles.map((p, pi) => {
          const done = ri < roomIdx || (ri === roomIdx && pi < puzzleIdx);
          const active = ri === roomIdx && pi === puzzleIdx;
          return (
            <div
              key={p.id}
              className={`h-2 rounded-full transition-all ${
                done ? "w-8 bg-accent" : active ? "w-12 bg-primary" : "w-2 bg-border"
              }`}
            />
          );
        }),
      )}
    </div>
  );
}

/* ============================================================
   ORDER PUZZLE
   ============================================================ */

function OrderPuzzle({ items, setItems }: { items: string[]; setItems: (v: string[]) => void }) {
  const [selected, setSelected] = useState<number | null>(null);

  function click(i: number) {
    if (selected === null) {
      setSelected(i);
    } else if (selected === i) {
      setSelected(null);
    } else {
      const next = [...items];
      [next[selected], next[i]] = [next[i], next[selected]];
      setItems(next);
      setSelected(null);
    }
  }

  return (
    <div>
      <p className="mb-2 text-xs uppercase tracking-widest text-foreground/60">
        Klik twee blokjes om te wisselen
      </p>
      <div className="grid grid-cols-4 gap-2">
        {items.map((it, i) => (
          <button
            key={i}
            onClick={() => click(i)}
            className={`rounded-xl border-2 px-2 py-4 font-display text-lg transition ${
              selected === i
                ? "border-primary bg-primary/30 scale-105"
                : "border-border bg-muted/40 hover:border-primary/60"
            }`}
          >
            <div className="text-xs text-foreground/50">{i + 1}</div>
            {it}
          </button>
        ))}
      </div>
    </div>
  );
}

/* ============================================================
   VAULT — eindkluis met 9-cijferige code
   ============================================================ */

function Vault({
  digits,
  onSolved,
}: {
  digits: Record<string, string>;
  onSolved: () => void;
}) {
  return (
    <div className="mt-10 text-center animate-in fade-in zoom-in-95 duration-700">
      <div className="text-xs uppercase tracking-[0.4em] text-primary/80">Eindkluis</div>
      <h1 className="mt-2 font-display text-5xl md:text-6xl text-primary flicker">
        Jullie geheime code
      </h1>
      <p className="mx-auto mt-3 max-w-xl text-foreground/80">
        Jullie hebben alle 30 raadsels opgelost! De cijfers van de laatste 7 raadsels vormen
        samen de geheime eindcode van de kluis.
      </p>

      <div className="mx-auto mt-8 flex max-w-2xl flex-wrap justify-center gap-2">
        {CODE_PUZZLES.map((p, i) => (
          <div key={p.id} className="rounded-xl border border-primary/40 bg-card/70 px-3 py-2 text-center">
            <div className="text-[10px] uppercase tracking-widest text-foreground/60">#{i + 1}</div>
            <div className="font-display text-3xl text-primary">{digits[p.id] ?? "?"}</div>
            <div className="text-[10px] text-foreground/50 max-w-[80px] truncate">{p.title}</div>
          </div>
        ))}
      </div>

      <div className="mx-auto mt-10 max-w-md rounded-3xl border-4 border-primary/60 bg-card/80 p-8 backdrop-blur">
        <div className="text-6xl mb-4">🔐</div>
        <div className="text-[10px] uppercase tracking-[0.3em] text-primary/80">Eindcode</div>
        <div className="my-2 font-display text-5xl tracking-[0.4em] text-primary">
          {CODE_PUZZLES.map((p) => digits[p.id] ?? "?").join("")}
        </div>
        <button
          onClick={onSolved}
          className="mt-5 w-full rounded-xl bg-primary px-6 py-4 font-display text-xl text-background glow-pulse transition hover:scale-105"
        >
          🔓 Open de kluis!
        </button>
      </div>
    </div>
  );
}

/* ============================================================
   VICTORY
   ============================================================ */

function Victory({
  time,
  digits,
  onRestart,
}: {
  time: number;
  digits: Record<string, string>;
  onRestart: () => void;
}) {
  return (
    <div className="relative mt-12 text-center">
      <Confetti />
      <div className="mb-6 text-9xl float-slow">🏆</div>
      <h1 className="font-display text-6xl text-primary">Ontsnapt!</h1>
      <p className="mx-auto mt-4 max-w-xl text-lg text-foreground/80">
        Je hebt de Gouden Dierensleutel verdiend en bewezen dat jij de slimste dierenkenner bent.
      </p>

      <div className="mx-auto mt-8 grid max-w-2xl grid-cols-2 gap-4">
        <div className="rounded-2xl border border-accent/40 bg-card/70 p-6 backdrop-blur">
          <div className="text-xs uppercase tracking-[0.3em] text-foreground/60">Eindtijd</div>
          <div className="font-display text-5xl text-accent">{formatTime(time)}</div>
        </div>
        <div className="rounded-2xl border border-primary/40 bg-card/70 p-6 backdrop-blur">
          <div className="text-xs uppercase tracking-[0.3em] text-foreground/60">Code gekraakt</div>
          <div className="font-display text-4xl text-primary tracking-widest">
            {CODE_PUZZLES.map((p) => digits[p.id] ?? "?").join("")}
          </div>
        </div>
      </div>

      <div className="paper mx-auto mt-8 max-w-2xl rounded-xl p-8 text-left">
        <h2 className="mb-3 font-display text-2xl">📜 Wat heb je geleerd?</h2>
        <ul className="space-y-2 text-base">
          <li>🦌 Er zijn ongeveer <strong>90 hertensoorten</strong> op aarde.</li>
          <li>🦌 Alleen mannetjes hebben een <strong>gewei</strong>.</li>
          <li>🦌 De <strong>ree</strong> is het kleinste hert van Nederland.</li>
          <li>🐄 De <strong>Brown Swiss</strong> is een Zwitsers melkras.</li>
          <li>🐄 Een koe is ongeveer <strong>9 maanden</strong> drachtig.</li>
          <li>🐄 Een koe groeit van <strong>kalf → pink → vaars → koe</strong>.</li>
          <li>🔬 Een koe heeft <strong>4 magen</strong>: pens, netmaag, boekmaag en lebmaag.</li>
          <li>🔬 De <strong>slokdarmsleuf</strong> stuurt melk direct naar de lebmaag.</li>
          <li>🔬 <strong>Kamille</strong> kalmeert de darm bij diarree.</li>
        </ul>
      </div>

      <button
        onClick={onRestart}
        className="mt-10 rounded-full bg-primary px-8 py-3 font-display text-lg text-background transition hover:scale-105"
      >
        🔄 Nog een keer spelen
      </button>
    </div>
  );
}

/* ============================================================
   DECOR
   ============================================================ */

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border border-border bg-card/60 px-3 py-1.5 backdrop-blur">
      <div className="text-[10px] uppercase tracking-widest text-foreground/50">{label}</div>
      <div className="font-display text-base text-primary">{value}</div>
    </div>
  );
}

function AmbientFog() {
  return (
    <>
      <div className="pointer-events-none fixed inset-0 fog-layer opacity-50" />
      <div className="pointer-events-none fixed inset-x-0 top-0 h-40 bg-gradient-to-b from-primary/10 to-transparent" />
    </>
  );
}

function Particles() {
  // Only render on client — random positions cause SSR hydration mismatch.
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  const dots = useMemo(
    () =>
      Array.from({ length: 24 }, (_, i) => ({
        id: i,
        left: Math.random() * 100,
        delay: Math.random() * 6,
        size: 2 + Math.random() * 4,
        dur: 6 + Math.random() * 8,
      })),
    [],
  );
  if (!mounted) return null;
  return (
    <div className="pointer-events-none fixed inset-0 overflow-hidden">
      {dots.map((d) => (
        <div
          key={d.id}
          className="absolute rounded-full bg-primary/30"
          style={{
            left: `${d.left}%`,
            top: "110%",
            width: d.size,
            height: d.size,
            animation: `float-slow ${d.dur}s ease-in-out ${d.delay}s infinite, fog 25s linear infinite`,
          }}
        />
      ))}
    </div>
  );
}

/* ============================================================
   TEAM LOBBY
   ============================================================ */

function TeamGate({ onCreated }: { onCreated: (t: TeamIdentity) => void }) {
  const [mode, setMode] = useState<"choose" | "create" | "join">("choose");
  const [name, setName] = useState("");
  const [code, setCode] = useState("");
  const [error, setError] = useState<string | null>(null);

  function doSolo() {
    const n = name.trim() || "Speler";
    onCreated({
      code: generateTeamCode(),
      me: { id: newMemberId(), name: n, isLeader: true, joinedAt: Date.now() },
      solo: true,
    });
  }
  function doCreate() {
    const n = name.trim();
    if (!n) return setError("Vul je naam in");
    onCreated({
      code: generateTeamCode(),
      me: { id: newMemberId(), name: n, isLeader: true, joinedAt: Date.now() },
    });
  }
  function doJoin() {
    const n = name.trim();
    const c = code.trim().toUpperCase();
    if (!n) return setError("Vul je naam in");
    if (c.length !== 4) return setError("Team-code is 4 tekens");
    onCreated({
      code: c,
      me: { id: newMemberId(), name: n, isLeader: false, joinedAt: Date.now() },
    });
  }

  return (
    <section className="relative z-10 mx-auto max-w-2xl px-6 pt-16 pb-24">
      <div className="text-center">
        <div className="mb-4 text-6xl float-slow">🔐</div>
        <h1 className="font-display text-4xl md:text-5xl text-foreground">Dieren Escape Room</h1>
        <p className="mt-3 text-foreground/70">
          Speel alleen, of in een team van 2 tot 5 spelers. De leider maakt een team en deelt de code.
        </p>
      </div>

      {mode === "choose" && (
        <div className="mt-10 grid gap-4 md:grid-cols-3">
          <button
            onClick={() => { setMode("create"); setError(null); }}
            className="rounded-2xl border border-primary/40 bg-card/60 p-6 text-left transition hover:border-primary hover:scale-[1.02]"
          >
            <div className="text-4xl mb-2">👑</div>
            <div className="font-display text-2xl">Maak een team</div>
            <div className="text-sm text-foreground/60 mt-1">2 t/m 5 spelers. Je krijgt een code om te delen.</div>
          </button>
          <button
            onClick={() => { setMode("join"); setError(null); }}
            className="rounded-2xl border border-border bg-card/60 p-6 text-left transition hover:border-primary hover:scale-[1.02]"
          >
            <div className="text-4xl mb-2">🤝</div>
            <div className="font-display text-2xl">Doe mee</div>
            <div className="text-sm text-foreground/60 mt-1">Vul de team-code in die je leider gaf.</div>
          </button>
          <button
            onClick={doSolo}
            className="rounded-2xl border border-border bg-card/60 p-6 text-left transition hover:border-accent hover:scale-[1.02]"
          >
            <div className="text-4xl mb-2">🧑‍🚀</div>
            <div className="font-display text-2xl">Speel alleen</div>
            <div className="text-sm text-foreground/60 mt-1">Solo — direct beginnen zonder team.</div>
          </button>
        </div>
      )}

      {(mode === "create" || mode === "join") && (
        <div className="mt-10 rounded-2xl border border-border bg-card/70 p-6 backdrop-blur">
          <div className="mb-4 text-xs uppercase tracking-[0.3em] text-primary/80">
            {mode === "create" ? "👑 Nieuw team aanmaken" : "🤝 Bij een team voegen"}
          </div>
          <label className="block text-sm text-foreground/70 mb-1">Jouw naam</label>
          <input
            value={name}
            onChange={(e) => { setName(e.target.value); setError(null); }}
            maxLength={20}
            placeholder="bv. Lotte"
            className="w-full rounded-lg border border-border bg-background px-4 py-3 text-lg focus:border-primary focus:outline-none"
          />
          {mode === "join" && (
            <>
              <label className="mt-4 block text-sm text-foreground/70 mb-1">Team-code (4 tekens)</label>
              <input
                value={code}
                onChange={(e) => { setCode(e.target.value.toUpperCase().slice(0, 4)); setError(null); }}
                maxLength={4}
                placeholder="bv. K7QM"
                className="w-full rounded-lg border border-border bg-background px-4 py-3 text-2xl font-mono tracking-[0.5em] uppercase focus:border-primary focus:outline-none"
              />
            </>
          )}
          {error && <div className="mt-3 text-sm text-destructive">{error}</div>}
          <div className="mt-6 flex gap-3">
            <button
              onClick={() => setMode("choose")}
              className="rounded-xl border border-border px-5 py-2 text-sm"
            >
              ← Terug
            </button>
            <button
              onClick={mode === "create" ? doCreate : doJoin}
              className="flex-1 rounded-xl bg-primary px-6 py-3 font-display text-lg text-background transition hover:scale-105"
            >
              {mode === "create" ? "👑 Team aanmaken" : "🚀 Doe mee"}
            </button>
          </div>
        </div>
      )}
    </section>
  );
}

function Lobby({
  team,
  members,
  channelReady,
  onStart,
}: {
  team: TeamIdentity;
  members: TeamMember[];
  channelReady: boolean;
  onStart: () => void;
}) {
  const [copied, setCopied] = useState(false);
  const full = members.length >= MAX_MEMBERS;
  const slots = Array.from({ length: MAX_MEMBERS }, (_, i) => members[i] ?? null);

  function copyCode() {
    if (typeof navigator !== "undefined" && navigator.clipboard) {
      navigator.clipboard.writeText(team.code);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    }
  }

  return (
    <div className="mt-10 animate-in fade-in duration-500">
      <div className="text-center">
        <div className="text-xs uppercase tracking-[0.3em] text-primary/80 mb-2">Wachtkamer</div>
        <h1 className="font-display text-4xl md:text-5xl">Team {team.code}</h1>
        <p className="mt-2 text-foreground/70">
          {team.me.isLeader
            ? "Deel de team-code met je 4 teamgenoten."
            : "Wacht tot je leider het spel start."}
        </p>
      </div>

      {/* Code box */}
      <div className="mx-auto mt-8 max-w-md">
        <div className="rounded-2xl border-2 border-primary/60 bg-card/70 p-6 text-center backdrop-blur shadow-[0_0_40px_-10px_var(--primary)]">
          <div className="text-xs uppercase tracking-[0.3em] text-foreground/60">Team-code</div>
          <div className="my-3 font-mono text-6xl font-bold tracking-[0.4em] text-primary">{team.code}</div>
          <button
            onClick={copyCode}
            className="rounded-lg border border-border bg-background/60 px-4 py-1.5 text-xs uppercase tracking-widest hover:border-primary"
          >
            {copied ? "✓ Gekopieerd" : "📋 Kopieer code"}
          </button>
        </div>
        <div className="mt-2 text-center text-xs text-foreground/50">
          {channelReady ? "🟢 Verbonden met team-kanaal" : "🟡 Verbinden..."}
        </div>
      </div>

      {/* Members */}
      <div className="mx-auto mt-10 max-w-2xl">
        <div className="mb-3 flex items-center justify-between text-sm">
          <div className="uppercase tracking-widest text-foreground/60">Teamleden</div>
          <div className="text-primary font-mono">{members.length} / {MAX_MEMBERS}</div>
        </div>
        <div className="grid gap-2 md:grid-cols-5">
          {slots.map((m, i) => (
            <div
              key={i}
              className={`rounded-xl border p-3 text-center transition ${
                m
                  ? m.isLeader
                    ? "border-primary bg-primary/10"
                    : "border-border bg-card/60"
                  : "border-dashed border-border/50 bg-card/20 opacity-60"
              }`}
            >
              <div className="text-2xl">{m ? (m.isLeader ? "👑" : "🧑") : "…"}</div>
              <div className="mt-1 text-sm font-bold truncate">{m ? m.name : "wachten"}</div>
              {m?.id === team.me.id && (
                <div className="text-[10px] uppercase tracking-widest text-primary mt-0.5">Jij</div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Start */}
      <div className="mt-10 text-center">
        {team.me.isLeader ? (
          <>
            <button
              onClick={onStart}
              disabled={members.length < 1}
              className="rounded-full bg-primary px-10 py-4 font-display text-xl text-background glow-pulse transition hover:scale-105 disabled:opacity-30 disabled:cursor-not-allowed disabled:hover:scale-100"
            >
              🎬 Start de missie ({members.length} {members.length === 1 ? "speler" : "spelers"})
            </button>
            <p className="mt-3 text-xs text-foreground/50">
              Je kunt starten met 1 tot 5 spelers. {!full && `Wacht eventueel op meer (max ${MAX_MEMBERS}).`}
            </p>
          </>
        ) : (
          <div className="inline-flex items-center gap-2 rounded-full border border-border bg-card/60 px-6 py-3 text-foreground/70">
            <span className="h-2 w-2 rounded-full bg-primary animate-pulse" />
            Wacht tot de leider start…
          </div>
        )}
      </div>
    </div>
  );
}


function Confetti() {
  const bits = useMemo(
    () =>
      Array.from({ length: 60 }, (_, i) => ({
        id: i,
        left: Math.random() * 100,
        delay: Math.random() * 2,
        color: ["#d97706", "#84cc16", "#f4e9d0", "#fbbf24"][i % 4],
        size: 6 + Math.random() * 10,
      })),
    [],
  );
  return (
    <div className="pointer-events-none absolute inset-0 -top-20 overflow-visible">
      {bits.map((b) => (
        <div
          key={b.id}
          className="absolute"
          style={{
            left: `${b.left}%`,
            top: 0,
            width: b.size,
            height: b.size,
            background: b.color,
            animation: `confetti-fall 3.5s ${b.delay}s linear infinite`,
            borderRadius: b.id % 3 === 0 ? "50%" : "2px",
          }}
        />
      ))}
    </div>
  );
}

function formatTime(s: number) {
  const m = Math.floor(s / 60);
  const r = s % 60;
  return `${String(m).padStart(2, "0")}:${String(r).padStart(2, "0")}`;
}

/* ============================================================
   AI NARRATION
   ============================================================ */

type NarrationState = "idle" | "loading" | "playing" | "error";

function useNarration() {
  const speak = useServerFn(speakText);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const cacheRef = useRef<Map<string, string>>(new Map());
  const reqIdRef = useRef(0);
  const [state, setState] = useState<NarrationState>("idle");

  function stop() {
    reqIdRef.current++;
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.src = "";
      audioRef.current = null;
    }
    setState("idle");
  }

  async function play(text: string) {
    stop();
    const myId = ++reqIdRef.current;
    setState("loading");
    try {
      let url = cacheRef.current.get(text);
      if (!url) {
        const res = await speak({ data: { text, voice: "shimmer" } });
        if (myId !== reqIdRef.current) return;
        url = `data:audio/mpeg;base64,${res.audio}`;
        cacheRef.current.set(text, url);
      }
      if (myId !== reqIdRef.current) return;
      const a = new Audio(url);
      audioRef.current = a;
      a.onended = () => {
        if (myId === reqIdRef.current) setState("idle");
      };
      a.onerror = () => {
        if (myId === reqIdRef.current) setState("error");
      };
      await a.play();
      if (myId === reqIdRef.current) setState("playing");
    } catch (e) {
      console.error("narration failed", e);
      if (myId === reqIdRef.current) setState("error");
    }
  }

  return { state, play, stop };
}

function NarrationControls({ n, text }: { n: ReturnType<typeof useNarration>; text: string }) {
  return (
    <div className="flex gap-2">
      {n.state === "playing" ? (
        <button
          onClick={() => n.stop()}
          className="rounded-full bg-primary/20 px-3 py-1 text-xs text-primary hover:bg-primary/30"
          aria-label="Stop voorlezen"
        >
          ⏸ Stop
        </button>
      ) : (
        <button
          onClick={() => n.play(text)}
          disabled={n.state === "loading"}
          className="rounded-full bg-primary/20 px-3 py-1 text-xs text-primary hover:bg-primary/30 disabled:opacity-50"
          aria-label="Opnieuw voorlezen"
        >
          {n.state === "loading" ? "⏳ …" : "🔊 Lees voor"}
        </button>
      )}
    </div>
  );
}
