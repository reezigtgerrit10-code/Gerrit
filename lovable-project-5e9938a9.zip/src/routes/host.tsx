import { createFileRoute, useSearch } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { INITIAL_STATE, type GameState } from "@/lib/gameState";
import { ROOMS, TOTAL_PUZZLES } from "@/lib/puzzles";
import { useHostChannel, type ScreenFrame } from "@/lib/team";

export const Route = createFileRoute("/host")({
  validateSearch: (s: Record<string, unknown>) => ({
    code: typeof s.code === "string" ? (s.code as string).toUpperCase() : "",
  }),
  head: () => ({
    meta: [
      { title: "Presentator-scherm • Dieren Escape Room" },
      { name: "description", content: "Live dashboard voor de presentator." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: HostScreen,
});

function HostScreen() {
  const search = useSearch({ from: "/host" });
  const [code, setCode] = useState<string>(search.code ?? "");
  const [input, setInput] = useState<string>(search.code ?? "");
  const [state, setState] = useState<GameState>(INITIAL_STATE);
  const [now, setNow] = useState(Date.now());
  const [screens, setScreens] = useState<Record<string, ScreenFrame>>({});

  useEffect(() => {
    const tick = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(tick);
  }, []);

  useHostChannel({
    code: code || null,
    onState: (s) => {
      const g = s as GameState;
      if (!g || typeof g.updatedAt !== "number") return;
      setState((cur) => (g.updatedAt > cur.updatedAt ? g : cur));
    },
    onScreen: (frame) => {
      setScreens((prev) => ({ ...prev, [frame.fromId]: frame }));
    },
  });

  if (!code) {
    return (
      <main className="min-h-screen bg-background text-foreground flex items-center justify-center px-6">
        <div className="w-full max-w-md rounded-3xl border border-border bg-card/60 p-8 backdrop-blur text-center">
          <div className="text-5xl mb-3">🎬</div>
          <h1 className="font-display text-2xl">Presentator-dashboard</h1>
          <p className="mt-2 text-sm text-foreground/70">
            Vul de team-code van je spelers in om live mee te kijken.
          </p>
          <input
            value={input}
            onChange={(e) => setInput(e.target.value.toUpperCase().slice(0, 4))}
            maxLength={4}
            placeholder="K7QM"
            className="mt-6 w-full rounded-lg border-2 border-border bg-background px-4 py-4 text-center font-mono text-3xl tracking-[0.5em] uppercase focus:border-primary focus:outline-none"
          />
          <button
            onClick={() => setCode(input.trim().toUpperCase())}
            disabled={input.trim().length !== 4}
            className="mt-5 w-full rounded-xl bg-primary px-6 py-3 font-display text-lg text-background disabled:opacity-40"
          >
            🔓 Verbinden
          </button>
        </div>
      </main>
    );
  }

  const elapsed = state.startedAt ? Math.floor((now - state.startedAt) / 1000) : state.elapsed;
  const currentRoom = ROOMS[state.roomIdx];
  const currentPuzzle = currentRoom?.puzzles[state.puzzleIdx];
  const solvedCount = state.solvedIds.length;
  const screenList = Object.values(screens).sort((a, b) => b.ts - a.ts);

  return (
    <main className="min-h-screen bg-background text-foreground">
      <header className="border-b border-border bg-card/40 backdrop-blur">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="text-3xl">🎬</div>
            <div>
              <div className="text-xs uppercase tracking-[0.3em] text-primary/80">
                Team {code} · live
              </div>
              <div className="font-display text-2xl">Dieren Escape Room — Presentator</div>
            </div>
          </div>
          <div className="flex items-center gap-3 text-xs">
            <span className="h-2 w-2 rounded-full bg-green-500 animate-pulse" />
            <span className="uppercase tracking-widest text-foreground/70">
              {state.stage === "lobby"
                ? "Wachtkamer"
                : state.stage === "intro"
                  ? "Missie-briefing"
                  : state.stage === "victory"
                    ? "Voltooid"
                    : state.stage === "vault"
                      ? "Eindkluis"
                      : "Live"}
            </span>
            <button
              onClick={() => setCode("")}
              className="ml-3 rounded border border-border px-2 py-1 uppercase tracking-widest text-foreground/60 hover:text-destructive"
            >
              ⎋ Code wijzigen
            </button>
          </div>
        </div>
      </header>

      <section className="mx-auto grid max-w-7xl gap-6 px-6 py-8 lg:grid-cols-3">
        <BigStat label="Tijd" value={formatTime(elapsed)} accent="text-primary" />
        <BigStat label="Opgelost" value={`${solvedCount} / ${TOTAL_PUZZLES}`} accent="text-accent" />
        <BigStat
          label="Cijfers verzameld"
          value={`${Object.keys(state.digits).length} / ${TOTAL_PUZZLES}`}
          accent="text-primary"
        />

        {/* Current location — geen vraag, geen antwoord */}
        <div className="lg:col-span-3 rounded-3xl border border-border bg-card/60 p-6 backdrop-blur">
          <div className="text-xs uppercase tracking-[0.3em] text-primary/80">Spelers zijn nu bij</div>
          {state.stage === "lobby" && (
            <div className="mt-3 font-display text-3xl">🪑 Wachtkamer — spelers komen binnen</div>
          )}
          {state.stage === "intro" && (
            <div className="mt-3 font-display text-3xl">🎬 Missie-briefing video</div>
          )}
          {state.stage === "playing" && currentPuzzle && (
            <>
              <div className="mt-2 font-display text-3xl">
                {currentRoom.emoji} {currentRoom.name}
              </div>
              <div className="mt-1 text-foreground/70">
                Raadsel {state.puzzleIdx + 1} / {currentRoom.puzzles.length}
              </div>
            </>
          )}
          {state.stage === "vault" && (
            <div className="mt-3 font-display text-3xl">🔐 Eindkluis</div>
          )}
          {state.stage === "victory" && (
            <div className="mt-3">
              <div className="font-display text-4xl text-accent">🏆 Ontsnapt!</div>
              <div className="mt-1 text-foreground/70">
                Eindtijd: <strong className="text-foreground">{formatTime(elapsed)}</strong>
              </div>
            </div>
          )}
          <div className="mt-3 text-sm text-foreground/60">{state.lastEvent}</div>
        </div>

        {/* Live screens van de spelers */}
        <div className="lg:col-span-3 rounded-3xl border border-border bg-card/60 p-6 backdrop-blur">
          <div className="mb-3 flex items-center justify-between">
            <div className="font-display text-xl">📺 Live schermen van de spelers</div>
            <div className="text-xs text-foreground/60">{screenList.length} aan het delen</div>
          </div>
          {screenList.length === 0 ? (
            <div className="rounded-xl border border-dashed border-border bg-background/30 p-8 text-center text-sm text-foreground/60">
              Nog geen scherm gedeeld. Vraag een speler om op{" "}
              <strong className="text-foreground">📺 Deel scherm</strong> te klikken in de balk
              bovenaan hun eigen scherm.
            </div>
          ) : (
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {screenList.map((f) => {
                const age = (Date.now() - f.ts) / 1000;
                return (
                  <div
                    key={f.fromId}
                    className="overflow-hidden rounded-xl border border-border bg-background/40"
                  >
                    <img src={f.dataUrl} alt={`Scherm van ${f.fromName}`} className="w-full" />
                    <div className="flex items-center justify-between px-3 py-2 text-xs">
                      <span className="font-bold">🧑 {f.fromName}</span>
                      <span className={age > 5 ? "text-amber-500" : "text-foreground/60"}>
                        {age < 2 ? "live" : `${Math.round(age)}s geleden`}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Voortgangsbord — alleen welke raadsels gedaan zijn, geen antwoorden */}
        <div className="lg:col-span-3 rounded-3xl border border-border bg-card/60 p-6 backdrop-blur">
          <div className="mb-4 font-display text-xl">📋 Voortgangsbord</div>
          <div className="grid gap-6 md:grid-cols-3">
            {ROOMS.map((r) => (
              <div key={r.id} className="rounded-2xl border border-border bg-background/40 p-4">
                <div className="mb-3 flex items-center gap-2">
                  <span className="text-2xl">{r.emoji}</span>
                  <div className="font-display text-lg">{r.name}</div>
                </div>
                <ul className="space-y-2">
                  {r.puzzles.map((p, i) => {
                    const done = state.solvedIds.includes(p.id);
                    const isNow =
                      state.stage === "playing" && currentPuzzle?.id === p.id;
                    return (
                      <li
                        key={p.id}
                        className={`flex items-center justify-between rounded-lg border px-3 py-2 text-sm ${
                          done
                            ? "border-accent/40 bg-accent/10"
                            : isNow
                              ? "border-primary bg-primary/10 animate-pulse"
                              : "border-border bg-muted/20"
                        }`}
                      >
                        <span className="flex items-center gap-2">
                          <span>{done ? "✅" : isNow ? "▶️" : "🔒"}</span>
                          <span className="text-foreground/90">Raadsel {i + 1}</span>
                        </span>
                        <span
                          className={`font-display text-xl ${
                            done ? "text-accent" : "text-foreground/30"
                          }`}
                        >
                          {done ? "✓" : "?"}
                        </span>
                      </li>
                    );
                  })}
                </ul>
              </div>
            ))}
          </div>
        </div>

        <div className="lg:col-span-3 rounded-2xl border border-dashed border-primary/30 bg-primary/5 p-4 text-sm text-foreground/70">
          💡 <strong className="text-foreground">Tip:</strong> de vragen en antwoorden zie je hier
          met opzet niet — zo blijft het spannend. Je ziet wel waar elk team is en (als ze delen)
          hun scherm live.
        </div>
      </section>
    </main>
  );
}

function BigStat({ label, value, accent }: { label: string; value: string; accent: string }) {
  return (
    <div className="rounded-3xl border border-border bg-card/60 p-6 backdrop-blur">
      <div className="text-xs uppercase tracking-[0.3em] text-foreground/60">{label}</div>
      <div className={`font-display text-5xl ${accent}`}>{value}</div>
    </div>
  );
}

function formatTime(s: number) {
  const m = Math.floor(s / 60);
  const r = s % 60;
  return `${String(m).padStart(2, "0")}:${String(r).padStart(2, "0")}`;
}
